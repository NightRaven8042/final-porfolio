document.addEventListener("DOMContentLoaded", () => {
  // Keep the footer year current.
  document.querySelectorAll(".current-year").forEach((element) => {
    element.textContent = new Date().getFullYear();
  });

  // Mobile navigation: keyboard accessible because it uses a real button.
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector("#site-nav");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isOpen));
      siteNav.classList.toggle("is-open", !isOpen);
    });
  }

  // DOM interaction: hide/show the skills list.
  const skillsToggle = document.querySelector("#skills-toggle");
  const skillsList = document.querySelector("#skills-list");

  if (skillsToggle && skillsList) {
    skillsToggle.addEventListener("click", () => {
      const isExpanded = skillsToggle.getAttribute("aria-expanded") === "true";
      skillsToggle.setAttribute("aria-expanded", String(!isExpanded));
      skillsToggle.textContent = isExpanded ? "Show skills" : "Hide skills";
      skillsList.hidden = isExpanded;
    });
  }

  // Client-side form validation.
  const form = document.querySelector("#contact-form");

  if (form) {
    const fields = {
      name: {
        input: document.querySelector("#name"),
        error: document.querySelector("#name-error"),
        message: "Please enter your name."
      },
      email: {
        input: document.querySelector("#email"),
        error: document.querySelector("#email-error"),
        message: "Please enter a valid email address."
      },
      message: {
        input: document.querySelector("#message"),
        error: document.querySelector("#message-error"),
        message: "Please enter a message."
      }
    };

    const success = document.querySelector("#form-success");

    const setError = (field, message) => {
      field.input.setAttribute("aria-invalid", "true");
      field.error.textContent = message;
    };

    const clearError = (field) => {
      field.input.removeAttribute("aria-invalid");
      field.error.textContent = "";
    };

    form.addEventListener("submit", (event) => {
      event.preventDefault();
      success.textContent = "";

      let firstInvalid = null;

      Object.values(fields).forEach(clearError);

      const nameValue = fields.name.input.value.trim();
      if (!nameValue) {
        setError(fields.name, fields.name.message);
        firstInvalid = firstInvalid || fields.name.input;
      }

      const emailValue = fields.email.input.value.trim();
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(emailValue)) {
        setError(fields.email, fields.email.message);
        firstInvalid = firstInvalid || fields.email.input;
      }

      const messageValue = fields.message.input.value.trim();
      if (!messageValue) {
        setError(fields.message, fields.message.message);
        firstInvalid = firstInvalid || fields.message.input;
      }

      if (firstInvalid) {
        firstInvalid.focus();
        return;
      }

      success.textContent = "Thanks! Your form passed validation.";
      form.reset();
    });
  }
});
